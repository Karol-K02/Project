package com.x.d6.vm;

import com.x.d6.util.C;
import lombok.extern.slf4j.Slf4j;
import org.zkoss.bind.annotation.CookieParam;
import org.zkoss.bind.annotation.Init;
import org.zkoss.zk.ui.Sessions;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

@Slf4j
@VariableResolver(DelegatingVariableResolver.class)
public class GenericVM {

    private final String TAG = C.g("GenericVM >");

    // VM init() ------------------------------------------------------------------------------------------------------
    public @Init void init(@CookieParam("JSESSIONID") String jSessionId) {
        log.debug("{} init() with JSESSIONID = {}", TAG, C.r(jSessionId));
    }

    // VM auxiliary methods --------------------------------------------------------------------------------------------
    public void setSessionAttr(String attrName, Object attrValue) {
        Sessions.getCurrent().setAttribute(attrName, attrValue);
    }

    // VM @COMMANDS ----------------------------------------------------------------------------------------------------

}
