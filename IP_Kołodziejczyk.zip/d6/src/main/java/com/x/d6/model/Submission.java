package com.x.d6.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table
@Data @RequiredArgsConstructor
public class Submission {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column private Long id;

    private @Column Long authorId;
    private @Column String title;
    private @Column String summary;
    private @Column String keywords;
    private @Column String lang = "pl";
    private @Column Integer pages;
    private @Column Integer status;
    private @Column Boolean archived = false;

    public enum STATUS { temporary, submitted, in_review, accepted, rejected, archived }

/*
INT8  id  (PK)
INT8  authorId  (FK)
TEXT  title
TEXT  summary
TEXT  keywords
TEXT  lang, (default: 'pl')
INT   pages
INT   status  (enum: temporary, submitted, in_review, accepted, rejected, archived)
BIT   archived
*/
}
