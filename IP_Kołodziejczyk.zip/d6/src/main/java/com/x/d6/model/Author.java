package com.x.d6.model;

import com.x.d6.util.En;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.sql.Date;

@Data
@RequiredArgsConstructor
@Entity
@Table
public class Author {

    public enum SALUTATION { none, mr, ms}
    public enum STATUS { unknown, regular, returning, reviewer, archived }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Long id;

    @Column
    private Integer salutation = SALUTATION.none.ordinal(); // ENUM stored as Int4 in the DB

    public static String getSalutationLabel(Integer salutation) {
        return En.enumName(salutation, SALUTATION.class);
    }

    @Column(nullable = false) @NonNull
    private String firstName;

    @Column(nullable = false) @NonNull
    private String lastName;

    @Column
    private Date birthdate;

    @Column(nullable = false) @NonNull
    private String email;

    @Column
    private String phone;

    @Column(unique = true)
    private String orcid;

    @Column
    private String status = STATUS.unknown.name();        // ENUM stored as VARCHAR in the DB

    public static Integer getStatusValue(String status) { return En.enumOrdinal(status, STATUS.class); }

    public Author() { }
}
