package com.x.d6.model;

import com.x.d6.util.En;
import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.sql.Date;

@Data
@RequiredArgsConstructor
@Entity
@Table
public class Buyer {

    public enum SALUTATION { NONE, MR, MS }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Long id;

    @Column
    private Integer salutation = SALUTATION.NONE.ordinal();

    public static String getSalutationLabel(Integer salutation) {
        return En.enumName(salutation, SALUTATION.class);
    }

    @Column(nullable = false) @NonNull
    @Size(max = 50, message = "Name too long")
    private String firstName;

    @Column(nullable = false) @NonNull
    @Size(max = 50, message = "Name too long")
    private String lastName;

    @Column
    private Date birthdate;

    @Column(nullable = false) @NonNull
    @Size(max = 50)
    private String email;

    @Column
    private String phone;

    @Column(unique = true)
    private String orcid;

    @Column
    @Max(value = 150, message = "Give a true age: must be less than or equal to 150")
    private int age;

    public Buyer(@NonNull String firstName, @NonNull String lastName, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;

    }


    public Buyer() {

    }
}
