package com.x.d6.vm;

import com.x.d6.model.Buyer;
import com.x.d6.repository.BuyerRepository;
import lombok.Getter;
import lombok.Setter;
import org.zkoss.bind.BindUtils;
import org.zkoss.bind.annotation.*;
import org.zkoss.zk.ui.select.annotation.WireVariable;
import org.zkoss.zk.ui.select.annotation.VariableResolver;
import org.zkoss.zk.ui.util.Clients;
import org.zkoss.zkplus.spring.DelegatingVariableResolver;

import java.util.List;
import java.util.Random;

@VariableResolver(DelegatingVariableResolver.class)
public class BuyerViewModel {

    @WireVariable
    private BuyerRepository buyerRepository;

    @Getter @Setter
    private Buyer buyer;

    @Getter
    private List<Buyer> buyers;

    @Init
    public void init() {
        this.buyer = new Buyer();
        this.loadBuyers();
    }

    @Command
    public void submitBuyer() {
        if (buyer.getFirstName() == null || buyer.getFirstName().isEmpty() ||
                buyer.getLastName() == null || buyer.getLastName().isEmpty() ||
                buyer.getEmail() == null || buyer.getEmail().isEmpty()) {
            Clients.showNotification("Please fill in all the required fields (First Name, Last Name, Email)", "error", null, null, 3000);
        } else if (buyer.getAge() < 18) {
            Clients.showNotification("Age must be at least 18", "error", null, null, 3000);
        } else if (!buyer.getEmail().contains("@")) {
            Clients.showNotification("Email must include the '@' symbol", "error", null, null, 3000);
        } else {
            buyerRepository.saveAndFlush(buyer);
            this.loadBuyers();
            BindUtils.postGlobalCommand(null, null, "refreshBuyersList", null);
            Clients.showNotification("Successfully submitted to buyers list", "info", null, null, 3000);
        }
    }
    @Command
    public void loadBuyers() {
        buyers = buyerRepository.findAll();
    }
    @Command
    public void pickWinner() {
        if (buyers != null && !buyers.isEmpty()) {
            int randomIndex = new Random().nextInt(buyers.size());
            Buyer winner = buyers.get(randomIndex);
            Clients.showNotification("Winner: " + winner.getFirstName() + " " + winner.getLastName() + " " + winner.getEmail(), "info", null, null, 3000);
        } else {
            Clients.showNotification("No users to pick from", "info", null, null, 3000);
        }
    }


    @GlobalCommand
    @NotifyChange("buyers")
    public void refreshBuyersList() {
        this.loadBuyers();
    }
    @Command
    @NotifyChange("buyers")
    public void clearTable() {
        buyerRepository.deleteAll();
        buyers.clear();
    }
}

