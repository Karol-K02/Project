package com.x.d6;

import com.x.d6.util.C;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@Slf4j
@Controller
@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.x.d6.repository")
public class D6Application {

    public static void main(String[] args) {
        SpringApplication.run(D6Application.class, args);
        log.info("Press {} to stop...\n---\n", C.y("CTRL+C"));
    }

    // Mappings
    @RequestMapping("/home")
    public String mapRoot() {
        return "th/start";
    }

    // Display forced HTTP Status + message
    // http://localhost:8080/force/401?message=Custom%20message
    @RequestMapping({"/force/{status}", "/force"})
    public void forceError(@PathVariable(required = false) Integer status,
                           @RequestParam(required = false, defaultValue = "Access forbidden!") String message)
            throws IllegalArgumentException {
        if (status == null)
            status = 403;
        throw new ResponseStatusException(HttpStatus.valueOf(status), "Forced status: " + status + " " + message);
    }
}
