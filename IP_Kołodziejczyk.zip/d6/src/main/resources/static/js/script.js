//
// Sample custom JS script...
//
console.log("Hello! CLASSPATH:static/js/script.js successfully loaded.")
