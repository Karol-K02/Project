package com.x.d6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D6ApplicationTests {

    @Test
    void contextLoads() {
    }

}
